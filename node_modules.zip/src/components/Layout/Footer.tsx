import React from 'react';

const Footer: React.FC = () => {
    return (
        <footer>
            <p>&copy; 2024 My App footer. All rights reserved</p>
            {/* Add footer content here */}
        </footer>
    );
};

export default Footer;